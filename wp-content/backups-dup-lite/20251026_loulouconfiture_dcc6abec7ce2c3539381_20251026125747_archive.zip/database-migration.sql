-- Database Migration Script for Loulou Confiture
-- Run this AFTER importing your local database to the hosting server
-- IMPORTANT: Your hosting uses table prefix 'xxml_' instead of 'wp_'

-- Update WordPress options table with new site URLs
-- Your hosting domain: http://loulouconfiture.com

UPDATE xxml_options SET option_value = 'http://loulouconfiture.com' WHERE option_name = 'home';
UPDATE xxml_options SET option_value = 'http://loulouconfiture.com' WHERE option_name = 'siteurl';

-- Update post content URLs (if any hardcoded URLs exist)
UPDATE xxml_posts SET post_content = REPLACE(post_content, 'http://localhost/loulouConfiture', 'http://loulouconfiture.com');
UPDATE xxml_posts SET post_content = REPLACE(post_content, 'localhost/loulouConfiture', 'loulouconfiture.com');

-- Update meta values that might contain URLs
UPDATE xxml_postmeta SET meta_value = REPLACE(meta_value, 'http://localhost/loulouConfiture', 'http://loulouconfiture.com');
UPDATE xxml_postmeta SET meta_value = REPLACE(meta_value, 'localhost/loulouConfiture', 'loulouconfiture.com');

-- Update comments if any contain URLs
UPDATE xxml_comments SET comment_content = REPLACE(comment_content, 'http://localhost/loulouConfiture', 'http://loulouconfiture.com');
UPDATE xxml_comments SET comment_author_url = REPLACE(comment_author_url, 'http://localhost/loulouConfiture', 'http://loulouconfiture.com');

-- Update user meta if needed
UPDATE xxml_usermeta SET meta_value = REPLACE(meta_value, 'http://localhost/loulouConfiture', 'http://loulouconfiture.com');

-- If you have customizer settings or theme options
UPDATE xxml_options SET option_value = REPLACE(option_value, 'http://localhost/loulouConfiture', 'http://loulouconfiture.com') WHERE option_name LIKE '%theme%';

-- Update widget settings if they contain URLs
UPDATE xxml_options SET option_value = REPLACE(option_value, 'http://localhost/loulouConfiture', 'http://loulouconfiture.com') WHERE option_name LIKE 'widget_%';

-- Check for any remaining localhost references
-- SELECT * FROM xxml_options WHERE option_value LIKE '%localhost%';
-- SELECT * FROM xxml_posts WHERE post_content LIKE '%localhost%';
-- SELECT * FROM xxml_postmeta WHERE meta_value LIKE '%localhost%';