<?php
/**
 * WordPress URL Migration Tool
 * Place this file in your WordPress root directory and run once after database import
 * Delete this file after use for security
 */

// CONFIGURATION
$old_url = 'http://localhost/loulouConfiture';
$new_url = 'http://loulouconfiture.com';

// Security check
if (!defined('WP_USE_THEMES')) {
    define('WP_USE_THEMES', false);
}

require_once('wp-config.php');
require_once('wp-includes/wp-db.php');

// Don't run this in production without authentication
if ($_SERVER['HTTP_HOST'] !== 'localhost' && !isset($_GET['confirm'])) {
    die('Add ?confirm=yes to URL to run this migration script');
}

echo "<h1>WordPress URL Migration Tool</h1>";
echo "<p>Migrating from: <strong>$old_url</strong></p>";
echo "<p>Migrating to: <strong>$new_url</strong></p>";

// Update options table
$options_updated = $wpdb->query($wpdb->prepare("
    UPDATE {$wpdb->options} 
    SET option_value = REPLACE(option_value, %s, %s) 
    WHERE option_name IN ('home', 'siteurl')
", $old_url, $new_url));

echo "<p>✓ Updated $options_updated option(s)</p>";

// Update post content
$posts_updated = $wpdb->query($wpdb->prepare("
    UPDATE {$wpdb->posts} 
    SET post_content = REPLACE(post_content, %s, %s)
", $old_url, $new_url));

echo "<p>✓ Updated $posts_updated post(s)</p>";

// Update postmeta
$postmeta_updated = $wpdb->query($wpdb->prepare("
    UPDATE {$wpdb->postmeta} 
    SET meta_value = REPLACE(meta_value, %s, %s)
", $old_url, $new_url));

echo "<p>✓ Updated $postmeta_updated postmeta record(s)</p>";

// Update comments
$comments_updated = $wpdb->query($wpdb->prepare("
    UPDATE {$wpdb->comments} 
    SET comment_content = REPLACE(comment_content, %s, %s)
", $old_url, $new_url));

echo "<p>✓ Updated $comments_updated comment(s)</p>";

// Special handling for serialized data (WordPress themes/widgets often use this)
$serialized_options = $wpdb->get_results("
    SELECT option_id, option_name, option_value 
    FROM {$wpdb->options} 
    WHERE option_value LIKE '%localhost%'
");

foreach ($serialized_options as $option) {
    $old_value = $option->option_value;
    $new_value = str_replace($old_url, $new_url, $old_value);
    
    // Handle serialized data
    if (is_serialized($old_value)) {
        $unserialized = maybe_unserialize($old_value);
        if ($unserialized !== false) {
            $new_value = maybe_serialize($unserialized);
        }
    }
    
    if ($old_value !== $new_value) {
        $wpdb->update(
            $wpdb->options,
            array('option_value' => $new_value),
            array('option_id' => $option->option_id)
        );
        echo "<p>✓ Updated serialized option: {$option->option_name}</p>";
    }
}

echo "<h2>Migration Complete!</h2>";
echo "<p><strong>Next Steps:</strong></p>";
echo "<ul>";
echo "<li>Delete this migration file</li>";
echo "<li>Go to WordPress Admin → Settings → Permalinks and click 'Save'</li>";
echo "<li>Test your website functionality</li>";
echo "<li>Check that images are displaying correctly</li>";
echo "</ul>";

// Helper function for serialized data check
function is_serialized($data, $strict = true) {
    if (!is_string($data)) {
        return false;
    }
    $data = trim($data);
    if ('N;' == $data) {
        return true;
    }
    if (strlen($data) < 4) {
        return false;
    }
    if (':' !== $data[1]) {
        return false;
    }
    if ($strict) {
        $lastc = substr($data, -1);
        if (';' !== $lastc && '}' !== $lastc) {
            return false;
        }
    } else {
        $semicolon = strpos($data, ';');
        $brace = strpos($data, '}');
        if (false === $semicolon && false === $brace)
            return false;
        if (false !== $semicolon && $semicolon < 3)
            return false;
        if (false !== $brace && $brace < 4)
            return false;
    }
    $token = $data[0];
    switch ($token) {
        case 's':
            if ($strict) {
                if ('"' !== substr($data, -2, 1)) {
                    return false;
                }
            } elseif (false === strpos($data, '"')) {
                return false;
            }
        case 'a':
        case 'O':
            return (bool) preg_match("/^{$token}:[0-9]+:/s", $data);
        case 'b':
        case 'i':
        case 'd':
            $end = $strict ? '$' : '';
            return (bool) preg_match("/^{$token}:[0-9.E-]+;$end/", $data);
    }
    return false;
}
?>