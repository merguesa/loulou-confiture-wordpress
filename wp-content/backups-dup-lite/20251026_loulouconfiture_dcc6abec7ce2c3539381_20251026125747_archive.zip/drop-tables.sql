-- SQL Commands to Drop All Tables with xxml_ prefix
-- Run these commands in phpMyAdmin before importing your converted database
-- WARNING: This will delete all existing data - make sure you have a backup!

-- Select the database first
USE `dbs14891707`;

-- Disable foreign key checks to avoid constraint errors
SET FOREIGN_KEY_CHECKS = 0;

-- Drop all WordPress core tables
DROP TABLE IF EXISTS `xxml_commentmeta`;
DROP TABLE IF EXISTS `xxml_comments`;
DROP TABLE IF EXISTS `xxml_links`;
DROP TABLE IF EXISTS `xxml_options`;
DROP TABLE IF EXISTS `xxml_postmeta`;
DROP TABLE IF EXISTS `xxml_posts`;
DROP TABLE IF EXISTS `xxml_terms`;
DROP TABLE IF EXISTS `xxml_term_relationships`;
DROP TABLE IF EXISTS `xxml_term_taxonomy`;
DROP TABLE IF EXISTS `xxml_usermeta`;
DROP TABLE IF EXISTS `xxml_users`;

-- Drop plugin-related tables (based on hosting database analysis)
DROP TABLE IF EXISTS `xxml_actionscheduler_actions`;
DROP TABLE IF EXISTS `xxml_actionscheduler_claims`;
DROP TABLE IF EXISTS `xxml_actionscheduler_groups`;
DROP TABLE IF EXISTS `xxml_actionscheduler_logs`;
DROP TABLE IF EXISTS `xxml_wfauditevents`;
DROP TABLE IF EXISTS `xxml_wfblockediplog`;
DROP TABLE IF EXISTS `xxml_wfblocks7`;
DROP TABLE IF EXISTS `xxml_wfconfig`;
DROP TABLE IF EXISTS `xxml_wfcrawlers`;
DROP TABLE IF EXISTS `xxml_wffilechanges`;
DROP TABLE IF EXISTS `xxml_wffilemods`;
DROP TABLE IF EXISTS `xxml_wfhits`;
DROP TABLE IF EXISTS `xxml_wfhoover`;
DROP TABLE IF EXISTS `xxml_wfissues`;
DROP TABLE IF EXISTS `xxml_wfknownfilelist`;
DROP TABLE IF EXISTS `xxml_wflivetraffichuman`;
DROP TABLE IF EXISTS `xxml_wflocs`;
DROP TABLE IF EXISTS `xxml_wflogins`;
DROP TABLE IF EXISTS `xxml_wfls_2fa_secrets`;
DROP TABLE IF EXISTS `xxml_wfls_role_counts`;
DROP TABLE IF EXISTS `xxml_wfls_settings`;
DROP TABLE IF EXISTS `xxml_wfnotifications`;
DROP TABLE IF EXISTS `xxml_wfpendingissues`;
DROP TABLE IF EXISTS `xxml_wfreversecache`;
DROP TABLE IF EXISTS `xxml_wfscanners`;
DROP TABLE IF EXISTS `xxml_wfsnipmalware`;
DROP TABLE IF EXISTS `xxml_wfstatus`;
DROP TABLE IF EXISTS `xxml_wftrafficrates`;
DROP TABLE IF EXISTS `xxml_wfwaffailures`;

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- Verify all tables are dropped (this should return empty result)
SHOW TABLES LIKE 'xxml_%';