-- Automated way to drop all xxml_ tables
-- This generates DROP statements for all tables with xxml_ prefix

SET @tables = NULL;
SELECT GROUP_CONCAT('`', table_name, '`') INTO @tables
FROM information_schema.tables
WHERE table_schema = 'dbs14891707' 
AND table_name LIKE 'xxml_%';

SET @tables = CONCAT('DROP TABLE IF EXISTS ', @tables);
PREPARE stmt FROM @tables;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Verify all tables are dropped
SELECT COUNT(*) as remaining_tables FROM information_schema.tables
WHERE table_schema = 'dbs14891707' 
AND table_name LIKE 'xxml_%';